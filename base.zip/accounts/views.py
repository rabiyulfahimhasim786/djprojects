from django.shortcuts import render
from django.http import HttpResponse, JsonResponse

from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import CurrenciesSerializer, StandardsSerializer, CountriesSerializer

from .models import Currencies, Standards, Countries


@api_view(['GET'])
def apiOverview(request):
  api_urls ={
    'List': '/task-list/',
    'Detail View': '/task-detail/<str:pk>/',
    'Create': '/task-create/',
    'Update':'/task-update/<str:pk>/',
    'Delete':'/task-delete/<str:pk>/',
    'Currencies': '/currencies-list/',
    'Countries': '/countries-list/',
    'Standards': '/standards-list/',
    'Currency': '/curreny-list/<str:pk>/',
    'Country': '/country-list/<str:pk>/',
    'Standard': '/standards-list/<str:pk>/',
  }
  return Response(api_urls)

@api_view(['GET'])
def currencyList(request):
  currencies = Currencies.objects.all()
  serializer = CurrenciesSerializer(currencies, many=True)
  return Response(serializer.data)

@api_view(['GET'])
def standardList(request):
  standards = Standards.objects.all()
  serializer = StandardsSerializer(standards, many=True)
  return Response(serializer.data)

@api_view(['GET'])
def countriesList(request):
  countries = Countries.objects.all()
  serializer = CountriesSerializer(countries, many=True)
  return Response(serializer.data)

@api_view(['POST'])
def currenciesCreate(request):  
  serializer = CurrenciesSerializer(data=request.data)
  
  if serializer.is_valid():
      serializer.save()

  return Response(serializer.data)

@api_view(['POST'])
def standardsCreate(request):  
  serializer = StandardsSerializer(data=request.data)
  
  if serializer.is_valid():
      serializer.save()

  return Response(serializer.data)

@api_view(['POST'])
def countriesCreate(request):  
  serializer = CountriesSerializer(data=request.data)
  
  if serializer.is_valid():
      serializer.save()

  return Response(serializer.data)