from django.urls import path

from . import views

urlpatterns = [
    path('', views.apiOverview, name="api-overview"), 
    path('currencies-list/', views.currencyList, name="currencies-list"),
    path('standards-list/', views.standardList, name="standards-list"),
    path('countries-list/', views.countriesList, name="countries-list"),
    path('currencies-list/post/', views.currenciesCreate, name="currencies-update"),
    path('standards-list/post/', views.standardsCreate, name="standards-update"),
    path('countries-list/post/', views.countriesCreate, name="countries-update"),
]